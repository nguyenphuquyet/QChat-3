import { useEffect, useState } from "react";
import { QChat, QChatError, type AppInfo, type SystemInfo } from "./sdk";
import DevCapsule from "./DevCapsule";

type Profile = { nickname: string; qchatId: string } | null;

type Step = { id: string; label: string; hint: string };

// Danh sách việc cần làm để màn hình mẫu trông như một app thật.
// Thay bằng tính năng của bạn; phần header và thẻ có thể giữ nguyên.
const steps: Step[] = [
  { id: "app", label: "Tạo ứng dụng", hint: "Làm trong Developer Center" },
  { id: "bridge", label: "Thử gọi cầu nối", hint: "Thông báo, hồ sơ, lưu trữ" },
  { id: "ship", label: "Đưa bản build lên", hint: "Tải file ZIP và gửi duyệt" },
];

export default function App() {
  const [app, setApp] = useState<AppInfo | null>(null);
  const [system, setSystem] = useState<SystemInfo | null>(null);
  const [profile, setProfile] = useState<Profile>(null);
  const [count, setCount] = useState(0);
  const [friends, setFriends] = useState<number | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [done, setDone] = useState<Record<string, boolean>>({ app: true });
  const [status, setStatus] = useState("");

  useEffect(() => {
    void (async () => {
      try {
        const [info, sys, saved] = await Promise.all([
          QChat.getAppInfo(),
          QChat.getSystemInfo(),
          QChat.getStorage<number>("counter"),
        ]);
        setApp(info);
        setSystem(sys);
        setCount(saved ?? 0);
      } catch (error) {
        setStatus(error instanceof QChatError ? error.message : "Không kết nối được với QChat");
      }
    })();
  }, []);

  useEffect(() => {
    // Host hiển thị mini app tràn màn hình nên cần dùng vùng an toàn mà host báo
    // (env(safe-area-inset-*) luôn bằng 0 trong Android WebView).
    const root = document.documentElement;
    root.style.setProperty("--safe-top", `${system?.safeAreaTop ?? 0}px`);
    root.style.setProperty("--safe-bottom", `${system?.safeAreaBottom ?? 0}px`);
  }, [system]);

  async function run(action: () => Promise<unknown>) {
    setStatus("");
    try {
      await action();
    } catch (error) {
      if (error instanceof QChatError) {
        setStatus(`${error.code}: ${error.message}`);
      } else {
        setStatus("Đã có lỗi xảy ra, thử lại nhé");
      }
    }
  }

  const completed = steps.filter((step) => done[step.id]).length;
  const progress = Math.round((completed / steps.length) * 100);

  return (
    <div className="app">
      {/* Chỉ hiện khi chạy npm run dev: nút ⋯ và × giả lập của host. */}
      <DevCapsule />
      {/* Host vẽ nút menu và nút đóng đè lên góc trên bên phải,
          nên header chừa sẵn một khoảng theo biến --capsule. */}
      <header className="app-bar">
        <div className="mark" aria-hidden="true">
          {(app?.name ?? "{{name}}").trim().slice(0, 1).toUpperCase()}
        </div>
        <div className="titles">
          <h1 title={app?.name}>{app?.name ?? "{{name}}"}</h1>
          <p className="subtitle">
            {app ? `Phiên bản ${app.version}` : "Mini App cho QChat"}
          </p>
        </div>
      </header>

      <main className="content">
        <section className="card">
          <p className="hello">Xin chào,</p>
          <h2 className="name">{profile ? profile.nickname : "Người dùng QChat"}</h2>
          <p className="muted">
            {profile ? `@${profile.qchatId}` : "Bấm “Tải hồ sơ” bên dưới để lấy thông tin của bạn."}
          </p>
          <div className="stats">
            <div>
              <b>{count}</b>
              <span>Bộ đếm</span>
            </div>
            <div>
              <b>{friends ?? "—"}</b>
              <span>Bạn bè</span>
            </div>
            <div>
              <b>{progress}%</b>
              <span>Tiến độ</span>
            </div>
          </div>
        </section>

        <section className="card">
          <div className="section-head">
            <h2>Bắt đầu nhanh</h2>
            <span className="pill">{completed}/{steps.length} xong</span>
          </div>
          <ul className="steps">
            {steps.map((step) => {
              const checked = Boolean(done[step.id]);
              return (
                <li key={step.id}>
                  <button
                    type="button"
                    className={`step${checked ? " checked" : ""}`}
                    aria-pressed={checked}
                    onClick={() => setDone((current) => ({ ...current, [step.id]: !checked }))}
                  >
                    <span className="tick" aria-hidden="true">{checked ? "✓" : ""}</span>
                    <span className="step-text">
                      <b>{step.label}</b>
                      <small>{step.hint}</small>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="card">
          <h2>Thử tính năng</h2>
          <p className="muted">
            {app ? `Mã ứng dụng: ${app.appId}` : "Đang kết nối với QChat…"}
          </p>
          <div className="grid-actions">
            <button onClick={() => void run(() => QChat.showToast("Xin chào từ {{name}}"))}>
              Hiện thông báo
            </button>
            <button
              className="ghost"
              onClick={() =>
                void run(async () => {
                  const next = count + 1;
                  await QChat.setStorage("counter", next);
                  setCount(next);
                })
              }
            >
              Đếm thêm 1
            </button>
            <button
              className="ghost"
              onClick={() =>
                void run(async () => {
                  const chosen = await QChat.chooseImage({ maxWidth: 1024, quality: 0.8 });
                  setImage(chosen.dataUrl);
                })
              }
            >
              Chọn ảnh
            </button>
            <button
              className="ghost"
              onClick={() =>
                void run(() =>
                  QChat.share({ text: "Làm bằng QChat Mini App", url: "https://qchat.example" }),
                )
              }
            >
              Chia sẻ
            </button>
            <button
              className="ghost"
              onClick={() =>
                void run(async () => {
                  const me = await QChat.getUserInfo();
                  setProfile(me ? { nickname: me.nickname, qchatId: me.qchatId } : null);
                })
              }
            >
              Tải hồ sơ
            </button>
            <button
              className="ghost"
              onClick={() =>
                void run(async () => {
                  const result = await QChat.request<{ items?: unknown[] }>("/friends");
                  setFriends(result.items?.length ?? 0);
                })
              }
            >
              Đọc bạn bè
            </button>
          </div>
          {image && <img className="preview" src={image} alt="Ảnh đã chọn" />}
          {status && <p className="status">{status}</p>}
        </section>

        <section className="card">
          <h2>Thiết bị</h2>
          {system ? (
            <dl>
              <div><dt>Hệ điều hành</dt><dd>{system.platform} {system.osVersion}</dd></div>
              <div><dt>Ngôn ngữ</dt><dd>{system.locale}</dd></div>
              <div><dt>Giao diện</dt><dd>{system.theme}</dd></div>
              <div><dt>Màn hình</dt><dd>{Math.round(system.screenWidth)} × {Math.round(system.screenHeight)}</dd></div>
            </dl>
          ) : (
            <p className="muted">Đang chờ thông tin từ QChat…</p>
          )}
        </section>
      </main>
    </div>
  );
}
