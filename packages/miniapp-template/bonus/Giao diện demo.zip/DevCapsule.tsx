// Mimics the two round buttons (⋯ and ×) that the QChat host floats over the
// top right corner. Rendered only by `npm run dev`; it is stripped from the
// production build because `import.meta.env.DEV` is false there.
export default function DevCapsule() {
  if (!import.meta.env.DEV) return null;

  return (
    <div className="dev-capsule" role="group" aria-label="Host buttons (dev preview)">
      <button type="button" aria-label="Menu" title="Host menu (preview)">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true">
          <circle cx="5" cy="12" r="1.9" />
          <circle cx="12" cy="12" r="1.9" />
          <circle cx="19" cy="12" r="1.9" />
        </svg>
      </button>
      <button type="button" aria-label="Close" title="Host close (preview)">
        <svg
          viewBox="0 0 24 24"
          width="18"
          height="18"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.6"
          strokeLinecap="round"
          aria-hidden="true"
        >
          <path d="M6 6l12 12M18 6L6 18" />
        </svg>
      </button>
    </div>
  );
}
